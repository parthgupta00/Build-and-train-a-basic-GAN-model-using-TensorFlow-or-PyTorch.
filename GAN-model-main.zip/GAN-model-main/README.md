# GAN-model
Build and train a basic GAN model using TensorFlow or PyTorch. [Dataset: MNIST dataset.]
